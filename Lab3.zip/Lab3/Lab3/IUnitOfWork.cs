namespace Lab3;

public interface IUnitOfWork
{
    Guid Id { get; }
}