namespace Lab3;

public interface ITransactionContext
{
    Guid TransactionId { get; }
}