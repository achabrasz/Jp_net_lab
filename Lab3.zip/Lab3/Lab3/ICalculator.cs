namespace Lab3;

public interface ICalculator
{
    public abstract string Eval(string a, string b);
}